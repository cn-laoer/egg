exports.nunjucks = {
    enable: true,
    package: 'egg-view-nunjucks'
};

// mysql 注入
exports.mysql = {
    enable: true,
    package: 'egg-mysql'
};

// 开启跨域
exports.cors = {
    enable: true,
    package: 'egg-cors'
};